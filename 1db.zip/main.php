<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>cover</title>
  <link rel="stylesheet"
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
  
  <style>
  @import url("https://fonts.googleapis.com/css2?family=poppins:wght@400;600&display=swap");
  * {
    margin: 0;
    padding: 0;
    border:none;
    outline: none;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
   
   }
    body {
  display: flex;
    }

.sidebar{
  
  position: sticky;
  top:0;
  left:0;
  bottom: 0;
  width: 115px;
  height: 100vh; /* Adjusted height */
  padding: 0 1.7rem;
  color:#fff;
  transition:all 0.5s linear;
  background:#ff2770;
  overflow: hidden;
}
.sidebar:hover{
width: 240px;
transition: 0.5s;
}
.logo{
  height: 80px;
  padding: 16px;

}
.menu{
height: 88%;
position: relative;
list-style: none;
padding: 0;

}
.menu li{
padding: 1rem;
margin: 8px 0;
border-radius: 8px;
transition: all 0.5s ease-in-out;

}
.menu li:hover{
background:#ff2770;
}
.menu a{
   color: #fff;
   font-size: 14px;
   text-decoration: none;
   display: flex;
   align-items: center;
   gap: 1.5rem;
}
.menu a span{
overflow: hidden;
}
.menu a i{
  font-size: 1.2rem;
}
.logout{
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;

}

.main--content{
    position: relative;
    width: 100%;
    padding: 1rem;
    display: flex; 
    flex-wrap: wrap;
    justify-content: space-around; 
}
.header--wrapper img {
  width: 50px;
  height: 50px;
  cursor:pointer;
  border-radius: 50%;

}
.header--wrapper {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  background: #ff2770;
  border-radius: 10px;
  padding: 20px 3rem; 
  margin-bottom: 1rem;
  width: 100%; 
}

.header--title{
  color:#fff
}
.user--info{
  display: flex;
  align-items: center;
  gap: 1;
}
.search--box{
  background: rgb(237, 237, 237);
  border-radius: 15px;
  color: rgba(113, 99, 186, 255);
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 4px 12px;
  
}
.search--box input{
  background: transparent;
  padding: 10px;

}
.search--box i{
  font-size: 1.2rem;
  cursor: pointer;
  transition: all 0.5s ease-out;
}
.search--box i:hover{
  transform: scale(1.1);
}

.additional-box {
  width: 300px;
  height: 200px;
  margin-top: 10px; 
  text-align: center;
  font-size: 20px;
  top: 3px;
  font-display:var(1.2rem)
}

.additional-box:nth-child(1) {
  background-color: #ffcc00; 
}

.additional-box:nth-child(2) {
  background-color: #66ccff; 
}

.additional-box:nth-child(3) {
  background-color: #ff6666; /* Red */
}

.additional-box:nth-child(4) {
  background-color: #99ff99; /* Green */
}
.additional-box:nth-child(5) {
  background-color: #99ffee; /* Green */
}
.additional-box:nth-child(6) {
  background-color: #ff99ff; /* Green */
}
.additional-box:nth-child(7) {
  background-color: #c999ff; /* Green */
}
.additional-box:nth-child(8) {
  background-color: #ffcf99af; /* Green */
}
.additional-box:nth-child(9) {
  background-color: #ffcf99af; /* Green */
}
/* Table */
.table-container {
  width: 100%;
  margin-top:0%;
}

.table {
  width: 100%;
  border-collapse: collapse;
}

.table th, .table td {
  padding: 8px;
  border-bottom: 1px solid #ddd;
  text-align: left;
}

.table th {
  background-color: #ff2770;
  color: #fff;
}
.h1{
  margin-top:900px;
  text-shadow: #ff2770;
  color: coral;
  font-style: oblique;
  text-align: left;
}

</style>
</head>
<body>
  <div class="sidebar">
    <div class="logo"></div>
    <ul class="menu">
      <li>
        <a href="#" class="active">
          <i class="fas fa-pills"></i>
          <span>Top up pharmacy</span>
        </a>
      </li>
      <li>
        <a href="#">
          <i class="fas fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>      
      <li>
        <a href="#">
          <i class="fas fa-capsules"></i>
          <span>Pharmacy Stock</span>
        </a>
      </li>
      <li>
        <a href="#">
          <i class="fas fa-store"></i>
          <span>Pharma Store</span>
        </a>
      </li>
      
      <li>
        <a href="#">
          <i class="fas fa-list-alt"></i>
          <span>Medicine List</span>
        </a>
      </li>
      
      <li>
        <a href="#">
          <i class="fas fa-shopping-cart"></i>
          <span>Sales</span>
        </a>
      </li>
      
      <li>
        <a href="#">
          <i class="fas fa-truck"></i>
          <span>Suppliers</span>
        </a>
      </li>
    
      <li>
        <a href="#">
          <i class="fas fa-file-invoice"></i>
          <span>Invoices</span>
        </a>
      </li>
      
      <li class="logout">
        <a href="#">
          <i class="fas fa-hourglass-end"></i>
          <span>Expired</span>
        </a>
      </li>
      
        </a>
      </li>
     </ul>
     </div>
      <div class="main--content">
        <div class="header--wrapper">
          <div class="header--title">
            <span>Primary</span>
            <h2>Dashboard</h2>
          </div>
          <div class="user--info">
          <div class="search--box">
            <i class="fa-solid
            fa-search"></i>
            <input type="text"
            placeholder="Search" />
          </div>
          <img src="C:\Users\Shri\Desktop\pharma\Medicines.jpg" alt="" />
        </div>
      </div>
      <script src="script.js"></script>
      
      <div class="box"></div> <!-- This is the box -->

      <!-- Additional Boxes -->
      <div class="additional-box">Medicines stock 
        <br>Total 10008
      </div>
      <div class="additional-box"></div>
      <div class="additional-box"></div>
      <div class="additional-box"></div>
      <div class="additional-box"></div>
      <div class="additional-box"></div>
      <div class="additional-box"></div>
      <div class="additional-box"></div>

      <div class="button-container">
        <button class="button" onclick="window.location.href='pharmas.html'">Patient Records</button>
      </div>

      <!-- Table -->
      <div class="table-container">
        <table class="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Quantity</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>Medicine A</td>
              <td>10</td>
            </tr>
            <tr>
              <td>2</td>
              <td>Medicine B</td>
              <td>15</td>
            </tr>
            <tr>
              <td>3</td>
              <td>Medicine C</td>
              <td>20</td>
            </tr>
            <tr>
              <tr>
                <td>4</td>
                <td>Medicine A</td>
                <td>10</td>
              </tr>
              <tr>
                <tr>
                  <td>5</td>
                  <td>Medicine A</td>
                  <td>10</td>
                </tr>
                <tr>
                  <tr>
                    <td>6</td>
                    <td>Medicine A</td>
                    <td>10</td>
                  </tr>
                  <tr>
                    <tr>
                      <td>7</td>
                      <td>Medicine A</td>
                      <td>10</td>
                    </tr>
                    <tr>
                      <tr>
                        <td>8</td>
                        <td>Medicine A</td>
                        <td>10</td>
                      </tr>
                      <tr>
              <td>9</td>
              <td>Medicine A</td>
              <td>10</td>
            </tr>
            <tr>
              <tr>
                <td>10</td>
                <td>Medicine A</td>
                <td>10</td>
              </tr>
              <tr>
          </tbody>
        </table>

        </div>
      </div>  
      <script src="script.js"></script>
</body>
</html>