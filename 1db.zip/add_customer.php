<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>cover</title>
  <link rel="stylesheet"
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
  
  <style>
  @import url("https://fonts.googleapis.com/css2?family=poppins:wght@400;600&display=swap");
  * {
    margin: 0;
    padding: 0;
    border:none;
    outline: none;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
   
   }
    body {
  display: flex;
    }

.sidebar{
  
  position: sticky;
  top:0;
  left:0;
  bottom: 0;
  width: 115px;
  height: 100vh; /* Adjusted height */
  padding: 0 1.7rem;
  color:#fff;
  transition:all 0.5s linear;
  background:#ff2770;
  overflow: hidden;
}
.sidebar:hover{
width: 240px;
transition: 0.5s;
}
.logo{
  height: 80px;
  padding: 16px;

}
.menu{
height: 88%;
position: relative;
list-style: none;
padding: 0;

}
.menu li{
padding: 1rem;
margin: 8px 0;
border-radius: 8px;
transition: all 0.5s ease-in-out;

}
.menu li:hover{
background:#ff2770;
}
.menu a{
   color: #fff;
   font-size: 14px;
   text-decoration: none;
   display: flex;
   align-items: center;
   gap: 1.5rem;
}
.menu a span{
overflow: hidden;
}
.menu a i{
  font-size: 1.2rem;
}
.logout{
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;

}
/*  ****  main body section  ****  */
.main--content{
    position: relative;
    width: 100%;
    padding: 1rem;
    display: flex; /* Added */
    flex-wrap: wrap; /* Added */
    justify-content: space-around; /* Added */
}
.header--wrapper img {
  width: 50px;
  height: 50px;
  cursor:pointer;
  border-radius: 50%;

}
.header--wrapper {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  background: #ff2770;
  border-radius: 10px;
  padding: 20px 3rem; /* Adjusted padding */
  margin-bottom: 1rem;
  width: 100%; /* Set the width to 100% */
}

.header--title{
  color:#fff
}
.user--info{
  display: flex;
  align-items: center;
  gap: 1;
}
.search--box{
  background: rgb(237, 237, 237);
  border-radius: 15px;
  color: rgba(113, 99, 186, 255);
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 4px 12px;
  
}
.search--box input{
  background: transparent;
  padding: 10px;

}
.search--box i{
  font-size: 1.2rem;
  cursor: pointer;
  transition: all 0.5s ease-out;
}
.search--box i:hover{
  transform: scale(1.1);
}
</style>

<body>
<header>
        <img src="C:\xampp\htdocs\dashboard\logo1.jpeg" alt="Logo">

    </header>

  <div class="sidebar">
    <div class="logo"></div>
    <ul class="menu">
      <li>
        <a href="#" class="active">
          <i class="fas fa-pills"></i>
          <span>Top up pharmacy</span>
        </a>
      </li>

      <li>
        <a href="#">
          <i class="fas fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li> 

      <li>
        <a href="#">
          <i class="fas fa-capsules"></i>
          <span>Pharmacy Stock</span>
        </a>
      </li>

      <li>
        <a href="#">
          <i class="fas fa-store"></i>
          <span>Pharma Store</span>
        </a>
      </li> 

       <li>
          <a href="#" onclick="showMedicineList()">
            <i class="fas fa-list-alt"></i>
            <span>Medicine List</span>
          </a>
      </li>
      
      <li>
        <a href="#">
          <i class="fas fa-shopping-cart"></i>
          <span>Sales</span>
        </a>
      </li>
      
      <li>
        <a href="#">
          <i class="fas fa-truck"></i>
          <span>Suppliers</span>
        </a>
      </li>

      
    
      <li>
        <a href="#">
          <i class="fas fa-file-invoice"></i>
          <span>Invoices</span>
        </a>
      </li>
      
      <li class="logout">
        <a href="#">
          <i class="fas fa-hourglass-end"></i>
          <span>Expired</span>
        </a>
      </li> 

      </a>
      </li>
     </ul>
     </div>
     <div class="main--content">
        <div class="header--wrapper">
          <div class="header--title">
            <span>Primary</span>
            <h2>Dashboard</h2>
          </div>
          <div class="user--info">
          <div class="search--box">
            <i class="fa-solid
            fa-search"></i>
            <input type="text"
            placeholder="Search" />
          </div>
          <img src="C:\Users\Shri\Desktop\pharma\Medicines.jpg" alt="" />
        </div>
      </div>

      <script src="script.js">
        function showMedicineList() {
          var medicineListContainer = document.getElementById("medicineListContainer");
          medicineListContainer.style.display = "block";
        }
      </script>
      </button>
      
</body>
</html>