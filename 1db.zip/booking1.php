<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>cover</title>
  <link rel="stylesheet"
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
  <body>

  <form action="db.php" method="post">
    <div class="form-group">
      <label for="name">Name:</label>
      <input type="text" id="name" name="Medicine" required>
    </div>
    <div class="form-group">
      <label for="name">email:</label>
      <input type="text" id="name" name="Generic" required>
    </div>
    <div class="form-group">
      <label for="name">mobile:</label>
      <input type="text" id="name" name="Supplier" required>
    </div>
    <div class="form-group">
      <label for="date">service:</label>
      <input type="date" id="date" name="Packing" required>
    </div>
    <div class="form-group">
      <label for="date">service:</label>
      <input type="date" id="date" name="Packing" required>
    </div>
    <div class="form-group">
      <label for="date">service:</label>
      <input type="date" id="date" name="Packing" required>
    </div>
    <div class="form-group">
      <button type="submit">Submit</button>
    </div>
    </form>
    <script>
      document.addEventListener("DOMContentLoaded", function() {
     const dropdowns = document.querySelectorAll('.dropdown');
     dropdowns.forEach(function(dropdown) {
         dropdown.addEventListener('click', function(event) {
             event.stopPropagation();
             this.querySelector('.dropdown-menu').classList.toggle('show');
         });
     });
     // Close the dropdown menu if the user clicks outside of it
     window.addEventListener('click', function(event) {
         dropdowns.forEach(function(dropdown) {
             if (!dropdown.contains(event.target)) {
                 dropdown.querySelector('.dropdown-menu').classList.remove('show');
             }
         });
     });
 });
     function showTable() {
       document.getElementById("patient-records").style.display = "block";
     }
    </script> 
</body>
</html>