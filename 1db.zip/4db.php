<?php
   $Customer_Name = $_POST['name'];
   $Address = $_POST['address'];
   $Invoice_No = $_POST['number'];
   $Payment_Type = $_POST['payment_type'];
   $Date = $_POST['date'];


   $conn = new mysqli('localhost','root','','test');
   if($conn->connect_error){
       die('Connection Failed : '.$conn->connect_error);
   }else{
       $stmt = $conn->prepare("insert into invoice(Customer_Name,Address,Invoice_No,Payment_Type,Date)
       values(?,?,?,?,?)");
       $stmt->bind_param("ssiss",$Customer_Name,$Address,$Invoice_No,$Payment_Type,$Date);
       $stmt->execute();
       echo "Recorded successfully";
       $stmt->close();
       $conn->close();   
      }

?>