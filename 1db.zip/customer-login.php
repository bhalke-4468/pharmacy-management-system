<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My School Website - Login</title>
    <link rel="stylesheet" href="style.css">
    <style>
       .background-video {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            z-index: -1;
        }
        
.logo {
  width: 100px; 
  height: 100px; 
  border-radius: 50%;
  object-fit: cover;
}

.navigation a {
  text-decoration: none;
  color: #333;
  padding: 10px;
  transition: background-color 0.3s ease;
}
.navigation a:hover {
    background:#ff276f50;
}
footer {
            color: black;
        }
      </style>
</head>

<body>
<video autoplay muted loop class="background-video">
        <source src="medicine video.mp4" type="video/mp4">
    </video>


    <header>
    <img src="newlogo.png" alt="logo" class="logo">
            <nav class="navigation">
                <br>
                <a href="pharmas.php">Home</a>
                <a href="#">Contact</a>
              </nav>  
        </nav>
    </header><br><br>

    <main>
        <div class="box">
            <form id="loginForm" onsubmit="return validateForm()">         
                <div class="inputBox">
                    <input type="text" id="username" required="required">
                    <span>Username</span>
                    <i></i>
                </div>
                <div class="inputBox">
                    <input type="password" id="password" required="required">
                    <span>Password</span>
                    <i></i>
                </div>
                <div class="links">
                    <a href="#">Forgot Password</a>
                    <a href="signup.php">Signup</a> 
                </div><br>
                <a href="mainn.php">
                    <input type="submit" value="Login">
                  </a>
            
        </div>
    </main>

    <footer>
        <p>&copy; 2024 My pharma. All rights reserved.</p>
    </footer>  

    <script src="script.js"></script>
</body>
</html>
