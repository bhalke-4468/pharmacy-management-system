
<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My School Website</title>
    <link rel="stylesheet" href="style.css">

<style>

.background-video {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            z-index: -1;
        }

.logo {
  width: 100px; 
  height: 100px; 
  border-radius: 50%;
  object-fit: cover;
}

.navigation a {
  text-decoration: none;
  color: #333;
  padding: 10px;
  transition: background-color 0.3s ease;
}
.navigation a:hover {
    background:#ff276f50;
}
footer {
            color: black;
        }
    </style>

</head>

<body>

<video autoplay muted loop class="background-video">
        <source src="medicine video.mp4" type="video/mp4">
    </video>


    <header>
    <img src="newlogo.png" alt="logo" class="logo">
        <nav>
            <nav class="navigation">
                <br>
                <a href="pharmas.php">Home</a>
                <a href="#">Contact</a>
              </nav>  
        </nav>
              </header>
      </nav>
    </header>
    
</body>

<main>
    <h1>PHARMACY POWERHOUSE</h1>
    <h2>"Streamline,Simplify,Succeed,Natural"</h2><br>
    <button id="lightingButton" onclick="window.location.href='customer-login.php';">LOGIN HERE</button>

    
</script>
    </main>

    <footer>
        <p>&copy; 2024 My pharma. All rights reserved.</p>
    </footer>

</body>
</html>

  