<?php
   $Medicine = $_POST['Medicine'];
   $Supplier = $_POST['Supplier'];
   $Generic = $_POST['Generic'];
   $Packing = $_POST['Packing'];
   
   //Database connection
   $conn = new mysqli('localhost','root','','test');
   if($conn->connect_error){
       die('Connection Failed :'.$conn->connect_error);
   }else{
       $stmt = $conn->prepare("insert into add_med(Medicine,Supplier,Generic,Packing)
       values(?,?,?,?)");
       $stmt->bind_param("ssss",$Medicine,$Supplier,$Generic,$Packing);
       $stmt->execute();
       echo "Recorded successfully";
       $stmt->close();
       $conn->close();   
      
      }

?>