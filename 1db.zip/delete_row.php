<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = ""; // Assuming your password is empty
$dbname = "test";

// Create connection
$conn = new mysqli('localhost','root','','test');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the row ID from the AJAX request
$rowId = $_POST['row_id'];

// SQL query to delete the row from the database table
$sql = "DELETE FROM add_med WHERE id = $rowId";

// Execute the query
if ($conn->query($sql) === TRUE) {
    echo "Row deleted successfully";
} else {
    echo "Error deleting row: " . $conn->error;
}

$conn->close();
?>
