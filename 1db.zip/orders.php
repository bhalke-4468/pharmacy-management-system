<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Table</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #ddd;
        }
        
    </style>

</head>
<body>
    <table>
        <tr>
            <td>Medicine</td>
            <td>Supplier</td>
            <td>Generic</td>
            <td>Packing</td>
        </tr>

        <?php
        // Database connection parameters
        $servername = "localhost";
        $username = "root";
        $password = ""; // Assuming your password is empty
        $dbname = "test";

        // Create connection
        $conn = new mysqli('localhost','root','','test');

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // SQL query to fetch data
        $sql = "SELECT * FROM cart";
        $result = $conn->query($sql);

        // Check if any rows are returned
        if ($result->num_rows > 0) {
            // Output data of each row
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["Medicine"] . "</td>";
                echo "<td>" . $row["Supplier"] . "</td>";
                echo "<td>" . $row["Generic"] . "</td>";
                echo "<td>" . $row["Packing"] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No records found</td></tr>";
        }
        $conn->close();
        ?>
    </table>
</body>
</html> 