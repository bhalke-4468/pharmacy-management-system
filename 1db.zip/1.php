<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>cover</title>
  <link rel="stylesheet"
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
  
  <style>
  @import url("https://fonts.googleapis.com/css2?family=poppins:wght@400;600&display=swap");
  * {
    margin: 0;
    padding: 0;
    border:none;
    outline: none;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
   
   }
  html,body {
  display: flex;
  height: 1000px; /* Set the height to 1500 pixels */
}
.background-video {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            z-index: -1;
        }

.sidebar{
  
  position: sticky;
  top:0;
  left:0;
  bottom: 0;
  width: 150px;
  height: 100vh; /* Adjusted height */
  padding: 0 1.7rem;
  color:#fff;
  transition:all 0.5s linear;
  background:#ff2770;
  overflow: hidden;
}
.sidebar:hover{
width: 300px;
transition: 0.5s;
}
.logo{
  height: 80px;
  padding: 16px;

}
.menu{
height: 88%;
position: relative;
list-style: none;
padding: 0;

}
.menu li{
padding: 1rem;
margin: 8px 0;
border-radius: 8px;
transition: all 0.5s ease-in-out;

}
.menu li:hover{
background:#ff2770;
}
.menu a{
   color: #fff;
   font-size: 14px;
   text-decoration: none;
   display: flex;
   align-items: center;
   gap: 2rem;
}
.menu a span{
overflow: hidden;
}
.menu a i{
  font-size: 1.5rem;
}
.logout{
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;

}

.main--content{
    position: relative;
    width: 100%;
    padding: 1rem;
    display: flex; 
    flex-wrap: wrap; 
    justify-content: space-around; 
}
.header--title {
  font-size: 24px; 
  border-bottom: 4px solid #ff2770; 
   padding-bottom: 20px; 
  text-align: center; 
}
form {
      width: 300px;
      margin: 0 auto;
    }

    label {
      display: block;
      margin-bottom: 10px;
    }

    input[type="text"],
    input[type="email"],
    select,
    textarea {
      width: 100%;
      padding: 8px;
      margin-bottom: 10px;
      box-sizing: border-box;
    }

    input[type="submit"] {
      background-color: #4CAF50;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    input[type="submit"]:hover {
      background-color: #45a049;
    }

    h1, h2 {
    text-align: center;
  }
  
  form {
    margin-top: 20px;
  }
  
  .form-group {
    margin-bottom: 20px;
    width: 600px;
  }
  
  .form-group label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
  }
  
  .form-group input[type="text"],
  .form-group input[type="email"],
  .form-group input[type="number"] {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
  }
  
  .form-group input[type="radio"],
  .form-group input[type="checkbox"] {
    margin-right: 5px;
  }
  
  .form-group textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
  }
  
  .form-group button {
    padding: 10px 20px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }
  
  .form-group button:hover {
    background-color: #0056b3;
  }
  .dropdown-menu {
        display: none;
        position: absolute;
        background-color: #ff99ff;
        min-width: 150px;
        box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
        z-index: 1;
    }
    .dropdown-menu a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
    }
    .dropdown-menu a:hover {
        background-color: #ff6666;
    }
    .dropdown:hover .dropdown-menu {
        display: block;
    }


</style>
</head>
<body>
<video autoplay muted loop class="background-video">
        <source src="medicine video.mp4" type="video/mp4">
    </video>

<div class="sidebar">
    <div class="logo"></div>
    <ul class="menu">
      <li>
        <a href="mainn.php">
          <i class="fas fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>      
      <ul>
        <li class="dropdown">
            <a href="#">
            <i class='fas fa-capsules'></i>
                <span>Medicine stock</span>
            </a>
            <div class="dropdown-menu">
                <a href="3.php">Add medicine</a>
                <a href="manage_medicine.php">Manage Medicines</a>  
                <a href="">View stock</a>
            </div>
        </li>
    </ul>
      <ul>
        <li class="dropdown">
            <a href="#">
                <i class="fas fa-user-alt"></i>
                <span>Customers</span>
            </a>
            <div class="dropdown-menu">
                <a href="1.php">Add Customers</a>
                <a href="">Customer login</a>
                <a href="manage_customer.php">Manage Customers</a> 
            </div>
        </li>
    </ul>

      <ul>
        <li class="dropdown">
            <a href="#">
                <i class="fas fa-users"></i>
                <span>Suppliers</span>
            </a>
            <div class="dropdown-menu">
                <a href="2.php">Add Supplier</a>
                <a href="manage_suppliers.php">Manage suppliers</a>
              
            </div>
        </li>
    </ul>
    <ul>
      <li class="dropdown">
          <a href="#">
              <i class="fab fa-cc-paypal"></i>
              <span>Invoices</span>
          </a>
          <div class="dropdown-menu">
              <a href="4.php">New invoices</a>
              <a href="invoice_history.php">Invoices History</a>   
          </div>
      </li>
  </ul> 
  <ul>
        <li class="dropdown">
            <a href="#">
            <i class="fas fa-shopping-cart"></i>
                <span>Order medicines</span>
            </a>
            <div class="dropdown-menu">
                <a href="https://pharmeasy.in/">Pharmeasy</a>
                <a href="https://www.netmeds.com/">Netmeds</a>
                <a href="https://www.1mg.com/?wpsrc=Google+Organic+Search">pharma limited</a> 
                <a href="orders.php">Total orders</a>
            </div>
        </li>
    </ul>

    </ul>
     </div>
     
      <div class="main--content">
        <div class="header--wrapper">
            <h1>Add Customer</h1><br>
            <div class="box"></div>

  <form action="1db.php" method="post">
    <div class="form-group">
      <label for="name">Name:</label>
      <input type="text" id="name" name="Name" required>
    </div>
    <div class="form-group">
      <label for="email">email:</label>
      <input type="email" id="email" name="email" required>
    </div>
    <div class="form-group">
      <label for="name">Contact:</label>
      <input type="number" id="number" name="Contact" required>
    </div>
    <div class="form-group">
      <label for="name">Address:</label>
      <input type="text" id="name" name="Address" required>
    </div>
    

    <div class="form-group">
      <button type="submit">Submit</button>
    </div>
    </form>
    <script>
      document.addEventListener("DOMContentLoaded", function() {
     const dropdowns = document.querySelectorAll('.dropdown');
     dropdowns.forEach(function(dropdown) {
         dropdown.addEventListener('click', function(event) {
             event.stopPropagation();
             this.querySelector('.dropdown-menu').classList.toggle('show');
         });
     });
 
     window.addEventListener('click', function(event) {
         dropdowns.forEach(function(dropdown) {
             if (!dropdown.contains(event.target)) {
                 dropdown.querySelector('.dropdown-menu').classList.remove('show');
             }
         });
     });
 });
     function showTable() {
       document.getElementById("patient-records").style.display = "block";
     }
    </script>
    
</body>
</html>

