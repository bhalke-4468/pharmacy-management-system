<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My pharma Website</title>
    <link rel="stylesheet" href="style.css">
</head>
<body> 
    <header>
    <img src="C:\Users\Shri\Desktop\pharma\logo1.jpeg" alt="Logo">
    <nav>
                <ul>
                    <li><a href="#home">Home</a></li>
                    <li><a href="#about">About Us</a></li>
                    <li><a href="#courses">Courses</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
  </nav>
</header><br><br><br>

<div class="box">
    <form action="first.php" method="post">
        <!-- Your form fields -->
           <h2>Sign Up</h2>
        <div class="inputBox">
            <input type="text" name="username">
            <span>username</span>
            <i></i>
        </div>
        <div class="inputBox">
            <input type="password" name="password">
            <span>password</span>
            <i></i>
        </div>
        <div class="inputBox">
            <input type="password" name="ConfirmPassword">
            <span>Confirm_password</span>
            <i></i>
        </div><input type="submit" value="Signup">
    </form>
</div>

<footer>
    <p>&copy; 2024 My School. All rights reserved.</p>
</footer>
</body>
</html>