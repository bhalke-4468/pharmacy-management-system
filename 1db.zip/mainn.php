<!-- <?php
$test = array( 
	array("y" => 64, "label" => "Cipla" ),
	array("y" => 94, "label" => "Acetaminophen" ),
	array("y" => 55, "label" => "Adderall" ),
	array("y" => 55, "label" => "Amitriptyline" ),
	
);
$link=mysqli_connect("localhost","root","");
mysqli_select_db($link,"test");
$count=0;
$res=mysqli_query($link,"select * from add_med");
while($row=mysqli_fetch_array($res))
{
    $test[$count]["label"]=$row["label"];
    $test[$count]["y"]=$row["y"];
    $count=$count+1;
}
?> -->

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>cover</title>
  <link rel="stylesheet"
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
  
  <style>
  @import url("https://fonts.googleapis.com/css2?family=poppins:wght@400;600&display=swap");
  * {
    margin: 0;
    padding: 0;
    border:none;
    outline: none;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
   
   }
  html,body {
  display: flex;
  height: 700px;
}
.background-video {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            z-index: -1;
        }

.sidebar{
  position: sticky;
  top:0;
  left:0;
  bottom: 0;
  width: 150px;
  height: 150vh; 
  padding: 0 1.7rem;
  color:#fff;
  transition:all 0.5s linear;
  background:#ff2770;
  overflow: hidden;
}
.sidebar:hover{
width: 350px;
transition: 0.5s;
}
.logo{
  height: 80px;
  padding: 16px;

}
.menu{
height: 88%;
position: relative;
list-style: none;
padding: 0;
}

.menu li{
padding: 1rem;
margin: 8px 0;
border-radius: 8px;
transition: all 0.5s ease-in-out;

}
.menu li:hover{
background:#ff2770;
}
.menu a{
   color: #fff;
   font-size: 14px;
   text-decoration: none;
   display: flex;
   align-items: center;
   gap: 1.5rem;
}
.menu a span{
overflow: hidden;
}
.menu a i{
  font-size: 1.2rem;
}
.logout{
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;

}
.main--content{
    position: relative;
    width: 100%;
    padding: 1rem;
    display: flex; 
    flex-wrap: wrap;
    justify-content: space-around; 
}
.header--wrapper img {
  width: 50px;
  height: 50px;
  cursor:pointer;
  border-radius: 50%;

}
.header--wrapper {
  display: flex;
  justify-content: space-between;
  height: 200px;
  align-items: center;
  flex-wrap: wrap;
  background: #ff2770;
  border-radius: 10px;
  padding: 20px 3rem;
  margin-bottom: 1rem;
  width: 100%; 
}
.header--title{
  color:#fff
}
.user--info{
  display: flex;
  align-items: center;
  gap: 1;
}
.search--box{
  background: rgb(237, 237, 237);
  border-radius: 15px;
  color: rgba(113, 99, 186, 255);
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 4px 12px;
  
}
.search--box input{
  background: transparent;
  padding: 10px;
}
.search--box i{
  font-size: 1.2rem;
  cursor: pointer;
  transition: all 0.5s ease-out;
}
.search--box i:hover{
  transform: scale(1.1);

}
.additional-box {
  width: 300px;
  height: 200px;
  margin-top: 50px; /* Adjusted margin-top */
  text-align: center;
  padding-top: 60px; 
  font-weight: bold;
  font-size: 20px;
  top: 3px;
  font-display:var(1.2rem)
}

.additional-box:nth-child(1) {
  background-color: #ffcc00; /* Yellow */
}

.additional-box:nth-child(2) {
  background-color: #66ccff; /* Blue */
}

.additional-box:nth-child(3) {
  background-color: #ff6666; /* Red */
}

.additional-box:nth-child(4) {
  background-color: #99ff99; /* Green */
}
.additional-box:nth-child(5) {
  background-color: #99ffee; /* Green */
}
.additional-box:nth-child(6) {
  background-color: #ff99ff; /* Green */
}
.additional-box:nth-child(7) {
  background-color: #c999ff; /* Green */
}
.additional-box:nth-child(8) {
  background-color: #ffcf99af; /* Green */
}

button{
align-items: center;
}

#patient-records {
  width: 100%;
  margin-top:0%;
    display: none;
    position: absolute;
    top: 90%;
    left: 50%;
    transform: translate(-50%, -50%);
  }
  .centered-table {
  margin: 0 auto; 
  width: 100%;
  padding-left: 400px;
  border-collapse: collapse;
  margin: 50px auto 0;
  margin-right: 20px;
}

.centered-table th, .centered-table td {
  border: 1px solid #000; 
  padding: 12px; 
  width: 300px;
}
.button-container {
  position: absolute;
  top: 80%;
  right: 950px;
  transform: translateY(-50%);
  background-color: #f0f0f0; 
  color: #333; 
  padding: 10px; 
}

.button {
  background-color: #ff6666; 
  border:none;
  padding: 10px 20px; 
  cursor: pointer; 
}

.button:hover {
  background-color:#ff276fa2;
  color: #333;
}
.dropdown-menu {
        display: none;
        position: absolute;
        background-color: #ff99ff;
        min-width: 150px;
        box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
        z-index: 1;
    }
    .dropdown-menu a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
    }
    .dropdown-menu a:hover {
        background-color: #ff6666;
    }
    .dropdown:hover .dropdown-menu {
        display: block;
    }
    
</style>

<script>
window.onload = function() {
 
 var chart = new CanvasJS.Chart("chartContainer", {
     animationEnabled: true,
     theme: "light2",
     title:{
         text: "Expired medicine stock"
     },
     axisY: {
         title: "No. of medicines"
     },
     data: [{
         type: "column",
         yValueFormatString: "#,##0.## No.",
         dataPoints: <?php echo json_encode($test, JSON_NUMERIC_CHECK); ?>
     }]
 });
 chart.render();
  
 }
</script>

<?php
$link = mysqli_connect("localhost", "root", "");
mysqli_select_db($link, "test");


$res = mysqli_query($link, "SELECT COUNT(*) AS total FROM add_med");
$row = mysqli_fetch_assoc($res);
$totalCount = $row['total'];
?>

<?php
$link = mysqli_connect("localhost", "root", "");
mysqli_select_db($link, "test");


$res = mysqli_query($link, "SELECT COUNT(*) AS supply_count FROM medicine_data");
$row = mysqli_fetch_assoc($res);
$todaySupplyCount = $row['supply_count'];
?>

<?php
$link = mysqli_connect("localhost", "root", "");
mysqli_select_db($link, "test");


$res = mysqli_query($link, "SELECT COUNT(*) AS Invoice_Count FROM invoice");
$row = mysqli_fetch_assoc($res);
$todayInvoiceCount = $row['Invoice_Count'];
?>

<?php
$link = mysqli_connect("localhost", "root", "");
mysqli_select_db($link, "test");


$res = mysqli_query($link, "SELECT COUNT(*) AS Invoice_order FROM cart");
$row = mysqli_fetch_assoc($res);
$todaysOrder = $row['Invoice_order'];
?>

</head>
<body>

<video autoplay muted loop class="background-video">
        <source src="medicine video.mp4" type="video/mp4">
    </video>

  <div class="sidebar">
    <div class="logo"></div>
    <ul class="menu">
      <li>
        <a href="mainn.php">
          <i class="fas fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>      
      <ul>
        <li class="dropdown">
            <a href="#">
            <i class='fas fa-capsules'></i>
                <span>Medicine stock</span>
            </a>
            <div class="dropdown-menu">
                <a href="3.php">Add medicine</a>
                <a href="manage_medicine.php">Manage Medicines</a> 
                <a href="expired.php">Expired medicines</a>
            </div>
        </li>
    </ul>
      <ul>
        <li class="dropdown">
            <a href="#">
                <i class="fas fa-user-alt"></i>
                <span>Customers</span>
            </a>
            <div class="dropdown-menu">
                <a href="1.php">Add Customers</a>
                <a href="manage_customer.php">Manage Customers</a> 
            </div>
        </li>
    </ul>

      <ul>
        <li class="dropdown">
            <a href="#">
                <i class="fas fa-users"></i>
                <span>Suppliers</span>
            </a>
            <div class="dropdown-menu">
                <a href="2.php">Add Supplier</a>
                <a href="manage_suppliers.php">Manage suppliers</a>
            </div>
        </li>
    </ul>
    <ul>
      <li class="dropdown">
          <a href="#">
              <i class="fab fa-cc-paypal"></i>
              <span>Invoices</span>
          </a>
          <div class="dropdown-menu">
              <a href="4.php">New invoices</a>
              <a href="invoice_history.php">Invoices History</a>   
          </div>
      </li>
  </ul> 
  <ul>
        <li class="dropdown">
            <a href="#">
            <i class="fas fa-shopping-cart"></i>
                <span>Order medicines</span>
            </a>
            <div class="dropdown-menu">
                <a href="https://pharmeasy.in/">Pharmeasy</a>
                <a href="https://www.netmeds.com/">Netmeds</a>
                <a href="https://www.1mg.com/?wpsrc=Google+Organic+Search">pharma limited</a> 
                <a href="orders.php">Total orders</a>
            </div>
        </li>
    </ul>

     </ul>
     </div>
     <div class="main--content">
        <div class="header--wrapper">
          <div class="header--title">
            <span>Primary</span>
            <h2>Dashboard</h2>
          </div>
          <div class="user--info">
          <div class="search--box">
            <i class="fa-solid
            fa-search"></i>
            <input type="text"
            placeholder="Search" />
          </div>
        </div>
      </div>
      
      <div class="box"></div> 

<div class="additional-box">
    Medicines stock Total<br>
    <span id="medicineCount"><?php echo $totalCount; ?></span>
  </div>

<div class="additional-box">
Expired medicines<br>Total:
<span id="medicineCount"><?php echo $totalCount; ?></span>
</div>

<div class="additional-box">
  Total Invoices<br>Total:
  <span id="medicineCount"><?php echo $todayInvoiceCount; ?></span>
</div>

<div class="additional-box">
  Todays order<br>Total:
  <span id="medicineCount"><?php echo $todaysOrder; ?></span>
</div>

<div class="additional-box">
    Total supply<br>
    Total: <?php echo $todaySupplyCount; ?>
  </div>

  <div class="additional-box">
Near to expire<br>Total:120
</div>

<div id="chartContainer" style="height: 300px; width: 70%;"></div>
<script src="https://cdn.canvasjs.com/canvasjs.min.js"></script>
      <script>

         document.addEventListener("DOMContentLoaded", function() {
        const dropdowns = document.querySelectorAll('.dropdown');
        dropdowns.forEach(function(dropdown) {
            dropdown.addEventListener('click', function(event) {
                event.stopPropagation();
                this.querySelector('.dropdown-menu').classList.toggle('show');
            });
        });
       
        window.addEventListener('click', function(event) {
            dropdowns.forEach(function(dropdown) {
                if (!dropdown.contains(event.target)) {
                    dropdown.querySelector('.dropdown-menu').classList.remove('show');
                }
            });
        });
    });
        function showTable() {
          document.getElementById("patient-records").style.display = "block";
        }
       </script>
       
<div id="chartContainer" style="height: 370px; width: 100%;"></div>
<script src="https://cdn.canvasjs.com/canvasjs.min.js"></script>
</body>
</html>