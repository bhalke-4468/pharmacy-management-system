function validateForm() {
  // Define the predefined username and password
  var predefinedUsername = "admin";
  var predefinedPassword = "admin123";

  // Get the values entered by the user
  var enteredUsername = document.getElementById("username").value;
  var enteredPassword = document.getElementById("password").value;

  // Check if the entered username and password match the predefined values
  if (enteredUsername === predefinedUsername && enteredPassword === predefinedPassword) {
      // If the credentials are correct, redirect to another page
      window.location.href = "mainn.php"; // Replace welcome.html with the desired page
      return false; // Prevent form submission
  } else {
      // If the credentials are incorrect, show an error message
      alert("Invalid username or password.");
      return false; // Prevent form submission
  }
}
