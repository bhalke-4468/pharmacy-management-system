<?php
   $Name = $_POST['Name'];
   $email = $_POST['email'];
   $Contact = $_POST['Contact'];
   $Address = $_POST['Address'];
   
   //Database connection
   $conn = new mysqli('localhost','root','','test');
   if($conn->connect_error){
       die('Connection Failed : '.$conn->connect_error);
   }else{
       $stmt = $conn->prepare("insert into table1(Name,email,Contact,Address)
       values(?,?,?,?)");
       $stmt->bind_param("ssis",$Name,$email,$Contact,$Address);
       $stmt->execute();
       echo "Recorded successfully";
       $stmt->close();
       $conn->close();   
      
      }

?>