<?php
   $Name = $_POST['Name'];
   $email = $_POST['email'];
   $Contact = $_POST['Contact'];
   $Address = $_POST['Address'];
   $DName = $_POST['DName'];

   //Database connection
   $conn = new mysqli('localhost','root','','test');
   if($conn->connect_error){
       die('Connection Failed : '.$conn->connect_error);
   }else{
       $stmt = $conn->prepare("insert into table1(Name,email,Contact,Address,DName)
       values(?,?,?,?,?)");
       $stmt->bind_param("ssiss",$Name,$email,$Contact,$Address,$DName);
       $stmt->execute();
       echo "Recorded successfully";
       $stmt->close();
       $conn->close();   
      
      }

?>