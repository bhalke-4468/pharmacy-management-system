<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = ""; // Assuming your password is empty
$dbname = "test";

// Create connection
$conn = new mysqli('localhost','root','','test');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the ID parameter is set
if (isset($_GET['id'])) {
    // Escape the ID to prevent SQL injection
    $id = $conn->real_escape_string($_GET['id']);

    // SQL query to delete the record with the specified ID
    $sql = "DELETE FROM table1 WHERE ID = $id";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
} else {
    echo "ID parameter is missing";
}

// Close the database connection
$conn->close();
?>
