<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Table</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #ddd;
        }
        
    </style>
     <script>
        function deleteRow(rowId) {
            if (confirm("Are you sure you want to delete this row?")) {
                // Send an AJAX request to delete the row
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "delete_row.php", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        // Reload the page to reflect changes
                        window.location.reload();
                    }
                };
                xhr.send("row_id=" + rowId);
            }
        }
    </script>

</head>
<body>
    <table>
        <tr>
            <td>Medicine</td>
            <td>Supplier</td>
            <td>Generic</td>
            <td>Packing</td>
            <td>Delete</td>
            <td>Expired</td>
        </tr>
        <?php
        // Database connection parameters
        $servername = "localhost";
        $username = "root";
        $password = ""; // Assuming your password is empty
        $dbname = "test";

        // Create connection
        $conn = new mysqli('localhost','root','','test');

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // SQL query to fetch data
        $sql = "SELECT * FROM add_med";
        $result = $conn->query($sql);

        // Check if any rows are returned
        if ($result->num_rows > 0) {
            // Output data of each row
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["Medicine"] . "</td>";
                echo "<td>" . $row["Supplier"] . "</td>";
                echo "<td>" . $row["Generic"] . "</td>";
                echo "<td>" . $row["Packing"] . "</td>";
                echo "<td><button>Delete</button></td>";  
                echo "<td><button>Expired</button></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No records found</td></tr>";
        }
        $conn->close();
        ?>
    </table>
</body>
</html> 